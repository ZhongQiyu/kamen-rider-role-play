drop table if exists hits;
