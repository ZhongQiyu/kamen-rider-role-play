drop table if exists target_table;
drop table if exists source_table;