drop table if exists customer;
drop table if exists lineitem;
drop table if exists nation;
drop table if exists orders;
drop table if exists partsupp;
drop table if exists part;
drop table if exists region;
drop table if exists supplier;
