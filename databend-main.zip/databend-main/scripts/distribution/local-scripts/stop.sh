echo "Stop Databend instances"
killall -9 databend-meta
killall -9 databend-query
