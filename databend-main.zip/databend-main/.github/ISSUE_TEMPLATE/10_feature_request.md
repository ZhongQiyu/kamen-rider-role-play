---
name: Feature request
title: 'Feature: '
about: Suggest an idea for Databend
labels: [ "C-feature" ]
---

**Summary**

Description for this feature.