﻿
// ClientDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "Client.h"
#include "ClientDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CClientDlg 对话框
SYSTEMTIME t;


CClientDlg::CClientDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CLIENT_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_IPADDRESS1, m_IpAddress);
	DDX_Control(pDX, IDC_EDIT1, m_Port);
	DDX_Control(pDX, IDC_BUTTON1, m_Connect);
	DDX_Control(pDX, IDC_BUTTON2, m_Send);
	DDX_Control(pDX, IDC_EDIT2, m_SendText);
	DDX_Control(pDX, IDC_LIST4, m_ListCtrl);
	DDX_Control(pDX, IDC_BUTTON3, m_Close);
}

BEGIN_MESSAGE_MAP(CClientDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_SOCKET, OnSocket)
	ON_BN_CLICKED(IDC_BUTTON1, &CClientDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CClientDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CClientDlg::OnBnClickedButton3)
END_MESSAGE_MAP()

// CClientDlg 消息处理程序

BOOL CClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	InitSocket();

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CClientDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

//初始化
void CClientDlg::InitSocket()
{
	//按钮变化
	m_Send.EnableWindow(false);
	m_SendText.EnableWindow(false);
	m_Close.EnableWindow(false);

	//初始化地址和端口
	char * strIP = "127.0.0.1";
	DWORD dwAddress = ntohl(inet_addr(strIP));
	m_IpAddress.SetAddress(dwAddress);
	m_Port.SetWindowText("8080");
}

//客户端连接
void CClientDlg::OnBnClickedButton1()
{
	// TODO: 在此添加控件通知处理程序代码
	CString str, str1;//定义字符串变量
	int port;//定义端口
	BYTE a, b, c, d;
	m_IpAddress.GetAddress(a, b, c, d);//获取服务器地址
	str.Format(_T("%d.%d.%d.%d"), a, b, c, d);
	m_Port.GetWindowText(str1);//获取端口地址

	if (str=="" || str1=="") {
		MessageBox(_T("服务器地址或端口不能为空"), _T("提示"), MB_ICONEXCLAMATION);
	}
	else {
		//初始化套接字动态库
		if (WSAStartup(MAKEWORD(2, 2), &wsd) != 0) {
			MessageBox(_T("WSAStartup error：" + WSAGetLastError()), _T("提示"), MB_ICONEXCLAMATION);
		}

		//创建TCP Socket，流式套接字
		s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (s == INVALID_SOCKET) {
			MessageBox(_T("create socket error : " + WSAGetLastError()), _T("提示"), MB_ICONEXCLAMATION);
		}
		
		//设置地址
		port=_ttoi(str1);//字符串转整型
		addr.sin_port = ntohs(port);//端口
		addr.sin_addr.S_un.S_addr = inet_addr(CT2CA(str));//网络字节序
		addr.sin_family = AF_INET;//地址族
		//int i = 0;
		if (::connect(s, (sockaddr*)&addr, sizeof(addr))!= SOCKET_ERROR) {
			//设置异步套接字
			::WSAAsyncSelect(s, this->m_hWnd, WM_SOCKET, FD_READ | FD_CLOSE);
			m_ListCtrl.InsertItem(0, _T("连接服务器成功"));
			//设置按钮变化
			m_Close.EnableWindow(true);
			m_Connect.EnableWindow(false);
			m_Port.EnableWindow(false);
			m_IpAddress.EnableWindow(false);
			m_Send.EnableWindow(true);
			m_SendText.EnableWindow(true);
		}
		else {
			m_ListCtrl.InsertItem(0, _T("连接服务器失败，请重试"));
		}
	}
}

//消息相应函数
LRESULT CClientDlg::OnSocket(WPARAM wPARAm, LPARAM lParam) {
	char buf[100] = { '\0' };
	switch (lParam) {
	case FD_READ:
	{
		//接收服务器消息
		::recv(s, buf, 100, 0);
		CString str1, str2;
		str1 = ::inet_ntoa(addr.sin_addr);
		str2.Format("%d", ntohs(addr.sin_port));
		m_ListCtrl.InsertItem(0, _T("服务器[" + str1 + ":" + str2 + "]：" + buf));
	}
	break;
	case FD_CLOSE:
	{
		//欲接收服务器关闭消息
		CString str1, str2;
		str1 = ::inet_ntoa(addr.sin_addr);
		str2.Format("%d", ntohs(addr.sin_port));
		//if (::WSAGetLastError() != WSAECONNRESET) {
			m_ListCtrl.InsertItem(0, _T("服务器[" + str1 + ":" + str2 + "]已关闭"));
			m_Connect.EnableWindow(true);
			m_Send.EnableWindow(false);
			m_SendText.EnableWindow(false);
		//}
		
	}
	break;
	}
	return 0;
}

//发送
void CClientDlg::OnBnClickedButton2()
{
	// TODO: 在此添加控件通知处理程序代码
	CString str1;
	m_SendText.GetWindowText(str1);//获取发送消息内容
	if (str1 == "") {
		MessageBox(_T("发送消息不能为空"), _T("提示"));
	}
	else {
		::send(s, CT2CA(str1), str1.GetLength(), 0);
		m_ListCtrl.InsertItem(0, _T("我说：" + str1));
		m_SendText.SetWindowText("");//清空
	}
}


//断开
void CClientDlg::OnBnClickedButton3()
{
	// TODO: 在此添加控件通知处理程序代码
	closesocket(s);
	::WSACleanup();

	m_Connect.EnableWindow(true);
	m_Close.EnableWindow(false);
	m_Send.EnableWindow(false);
	m_SendText.EnableWindow(false);
	m_Port.EnableWindow(true);
	m_IpAddress.EnableWindow(true);
	//清空
	//m_ListCtrl.DeleteAllItems();
}


