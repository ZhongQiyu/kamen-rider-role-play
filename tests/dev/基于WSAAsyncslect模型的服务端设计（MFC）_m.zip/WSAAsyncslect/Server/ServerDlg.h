﻿
// ServerDlg.h: 头文件
//

#pragma once
#define WM_SOCKET WM_USER+1000
#include <vector>
using namespace std;

// CServerDlg 对话框
class CServerDlg : public CDialogEx
{
// 构造
public:
	CServerDlg(CWnd* pParent = nullptr);	// 标准构造函数
// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SERVER_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg LRESULT OnSocket(WPARAM wPARAm, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
public:
	WSADATA wsd;//WSADATA变量
	SOCKET listenSocket;//服务器监听套接字
	SOCKET acceptSocket;//接受客户端连接请求的套接字
	sockaddr_in addr;
	sockaddr_in addr1;
	int n = 0;//客户端数
	SOCKET s[10];//套接字数组
	int flag = 0;
	//SOCKET socket_arr[100];//存放acceptsocket
	vector<SOCKET> socket_arr[100];
	int count = 0;


	CListCtrl m_Listctrl;
	CEdit m_SendText;
	CButton m_Send;
	CIPAddressCtrl m_Ip;
	CEdit m_Port;
	CButton m_Start;
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton1();
	CButton m_Close;
	afx_msg void OnBnClickedButton3();
	CEdit m_num;
	void InitSocket();
};
