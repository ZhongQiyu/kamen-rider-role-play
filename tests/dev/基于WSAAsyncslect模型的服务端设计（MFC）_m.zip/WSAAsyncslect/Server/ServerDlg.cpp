﻿
// ServerDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "Server.h"
#include "ServerDlg.h"
#include "afxdialogex.h"
#include <iostream>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CServerDlg 对话框



CServerDlg::CServerDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SERVER_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_Listctrl);
	DDX_Control(pDX, IDC_EDIT1, m_SendText);
	DDX_Control(pDX, IDC_BUTTON1, m_Send);
	DDX_Control(pDX, IDC_IPADDRESS1, m_Ip);
	DDX_Control(pDX, IDC_EDIT2, m_Port);
	DDX_Control(pDX, IDC_BUTTON2, m_Start);
	DDX_Control(pDX, IDC_BUTTON3, m_Close);
	DDX_Control(pDX, IDC_EDIT3, m_num);
}

BEGIN_MESSAGE_MAP(CServerDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON2, &CServerDlg::OnBnClickedButton2)
	ON_MESSAGE(WM_SOCKET, OnSocket)
	ON_BN_CLICKED(IDC_BUTTON1, &CServerDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON3, &CServerDlg::OnBnClickedButton3)
END_MESSAGE_MAP()


// CServerDlg 消息处理程序

BOOL CServerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	InitSocket();//初始化

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CServerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CServerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


//初始化
void CServerDlg::InitSocket()
{
	//按钮初始化
	m_Send.EnableWindow(false);
	m_SendText.EnableWindow(false);
	m_Close.EnableWindow(false);
	//m_Listctrl.ShowScrollBar(SB_VERT, TRUE);
	//服务器地址ip和端口初始化
	char * strIP = "127.0.0.1";
	DWORD dwAddress = ntohl(inet_addr(strIP));
	m_Ip.SetAddress(dwAddress);
	m_Port.SetWindowText("8080");
}



//启动服务器
void CServerDlg::OnBnClickedButton2()
{
	CString str, str1;
	BYTE a, b, c, d;
	m_Ip.GetAddress(a, b, c, d);//获取服务器地址
	str.Format(_T("%d.%d.%d.%d"), a, b, c, d);//CString->int
	m_Port.GetWindowText(str1);//获取端口号

	//设置地址
	addr.sin_family = AF_INET;//地址族
	addr.sin_port = htons(_ttoi(str1));//端口号
	addr.sin_addr.S_un.S_addr = inet_addr(CT2CA(str));//IP地址
	//创建套接字
	listenSocket = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	//绑定套接字
	::bind(listenSocket, (sockaddr*)&addr, sizeof(addr));
	//监听套接字
	::listen(listenSocket, 5);
	//输出
	CString str2, str3;
	str2 = ::inet_ntoa(addr.sin_addr);//返回点分十进制的字符串
	str3.Format("%d", ntohs(addr.sin_port)); //ntohs主要是将网络字节转为主机字节
	m_Listctrl.InsertItem(count++, _T("服务器["+str2+":"+str3+"]已启动监听..."));
	//按钮变化
	m_Start.EnableWindow(false);
	m_Close.EnableWindow(true);
	//设置异步套接字
	::WSAAsyncSelect(listenSocket, this->m_hWnd, WM_SOCKET, FD_ACCEPT | FD_READ | FD_CLOSE);
}

//消息响应函数
LRESULT CServerDlg::OnSocket(WPARAM wPARAm, LPARAM lParam) {
	CString str;
	switch (lParam) {
	case FD_ACCEPT:
	{
		//accept函数返回一个新的套接字，同时返回客户端的IP地址，初始化ClientAddr
		int len = sizeof(addr1);
		acceptSocket = ::accept(listenSocket, (sockaddr*)&addr1, &len);
		//添加套接字
		socket_arr->push_back(acceptSocket);
		flag++;
		n = n + 1;//客户端数加一
		CString str1, str2,str3;
		str1 = ::inet_ntoa(addr1.sin_addr);//返回点分十进制的字符串
		str2.Format("%d", ntohs(addr1.sin_port)); //ntohs主要是将网络字节转为主机字节
		str.Format("目前有%d个客户端\n", n);
		str3.Format("%d", flag);
		
		m_Listctrl.InsertItem(count++, _T("用户"+str3+"[" + str1 + ":" + str2 + "]已经连接成功"));
		m_Listctrl.InsertItem(count++, _T(str));
		
		//按钮变化
		m_Send.EnableWindow(true);
		m_SendText.EnableWindow(true);
	}
	break;
	case FD_READ:
	{
		//接收消息
		char buf[100] = { '\0' };
		int ret = 0;
		int i = 0;
		//迭代器遍历
		for (vector<SOCKET>::iterator it = socket_arr->begin(); it != socket_arr->end(); it++) {
			ret=::recv(*it, buf, 100, 0);
			SOCKADDR_IN addClient;
			int nLen = sizeof(addClient);
			//获取当前连接的客户端的IP地址和端口号,即初始化addClient
			getpeername(socket_arr->at(i), (sockaddr*)&addClient, &nLen);
			CString str, str1, str2;
			str.Format("%d", i + 1);
			str1 = ::inet_ntoa(addClient.sin_addr);
			str2.Format("%d", ntohs(addClient.sin_port));
			if (ret > 0) {//说明有数据
				m_Listctrl.InsertItem(count++, _T("用户" + str +"["+str1+":"+str2+ "]说:" + buf));
			}
			i++;
		}
		
	}
	break;
	case FD_CLOSE:
	{
		//欲接收客户端关闭情况
		int ret = 0;
		char buf[100] = { '\0' };
		int i = 0;
		for (vector<SOCKET>::iterator it = socket_arr->begin(); it != socket_arr->end(); it++) {
			ret = ::recv(*it, buf, 100, 0);
			if (ret==0){
				//客户端数量减一
				n = n - 1;
				CString str;
				str.Format("目前有%d个客户端\n", n);

				SOCKADDR_IN addClient;
				int nLen = sizeof(addClient);
				//获取当前连接的客户端的IP地址和端口号,即初始化addClient
				getpeername(*it, (sockaddr*)&addClient, &nLen);
				CString str1, str2,str3;
				str1 = ::inet_ntoa(addClient.sin_addr);
				str2.Format("%d", ntohs(addClient.sin_port));
				str3.Format("%d", i+1);

				m_Listctrl.InsertItem(count++, _T("用户"+str3+"[" + str1 + ":" + str2 + "]主动关闭"));
				m_Listctrl.InsertItem(count++, _T(str));
				//当没有客户端，按钮变化
				if (!(n > 0)) {
					m_Send.EnableWindow(false);
					m_SendText.EnableWindow(false);
				}
				

				//删除对应accepsocket
				it = socket_arr->erase(it);
				if (it == socket_arr->end()) {
					break;
				}
			}
		}
	}
	break;
	}
	return 0;
}


//发送消息
void CServerDlg::OnBnClickedButton1()
{
	// TODO: 在此添加控件通知处理程序代码
	CString str = "";
	m_SendText.GetWindowText(str);//获取发送消息的内容
	if (str == "") {
		MessageBox(_T("发送消息不能为空"), _T("提示"));
	}
	else {
		CString str1;
		m_num.GetWindowText(str1);//选择客户端进行发送
		if (str1 == "") {
			MessageBox(_T("发送的人不能为空"), _T("提示"));
		}
		else {
			int num = _ttoi(str1);
			if (::send(socket_arr->at(num-1), CT2CA(str), str.GetLength(), 0) != SOCKET_ERROR) {
				m_Listctrl.InsertItem(count++, _T("服务器对用户" + str1 + "说：" + str));
				m_SendText.SetWindowText("");//清空
				m_num.SetWindowText("");
			}
			else {
				MessageBox(_T("发送消息失败"), _T("提示"));
			}
		}
		
	}
}

//断开
void CServerDlg::OnBnClickedButton3()
{
	// TODO: 在此添加控件通知处理程序代码
	closesocket(listenSocket);
	closesocket(acceptSocket);
	WSACleanup();
	m_Send.EnableWindow(false);
	m_SendText.EnableWindow(false);
	m_Start.EnableWindow(true);
	m_Close.EnableWindow(false);
	m_Listctrl.InsertItem(count++, _T("服务器已关闭"));
}

